/**
 * jQuery Timepicker - v1.3.1 - 2014-02-15
 * http://wvega.github.com/timepicker/
 *
 * Enhances standard form input fields helping users to select (or type) times.
 *
 * Copyright (c) 2014 Willington Vega; Licensed MIT, GPL
 */

# jQuery Timepicker [![Build Status](https://travis-ci.org/wvega/timepicker.png?branch=master)](https://travis-ci.org/wvega/timepicker)

A jQuery plugin to enhance standard form input fields helping users to select
(or type) times.

Please visit http://wvega.github.com/timepicker/ for Documentation, Examples 
and Getting Started information.

## Release History

See [CHANGELOG](https://github.com/wvega/timepicker/blob/master/CHANGELOG).

## License
Copyright (c) 2012 Willington Vega
Licensed under the MIT, GPL licenses.
